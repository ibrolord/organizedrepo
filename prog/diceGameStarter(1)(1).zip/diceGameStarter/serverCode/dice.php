<?php
	$choiceNum	= $_GET["txtNumber"];
	$numFound	= 0;
	$path		= "../icons";
	$dice		= array("<img src='$path/One.png'>",
						"<img src='$path/Two.png'>",
						"<img src='$path/Three.png'>",
						"<img src='$path/Four.png'>",
						"<img src='$path/Five.png'>",
						"<img src='$path/Six.png'>");
						
	//IN CLASS REVIEW AND ENHANCED LEARNING: 
	//WE WILL ADD CODE HERE TOGETHER TO START
	//THE DICE ROLLING GAME
	
	
	//YOU WILL ADD YOUR OWN CODE HERE TO GET THE COOKIE
	//CODE WORKING. THE GOAL IS TO STORE THE RUNNING TOTAL 
	//FOR THE ROUND
	
?>