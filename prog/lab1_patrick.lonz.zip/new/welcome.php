<?php

$gear     = $_GET["chk"];
$shipping = $_GET["shiprad"];
$currency = $_GET["cur"];
$items    = count($gear);
$US       = "0.74";
$brit     = "0.61";
$cost     = "0";

if (empty($gear)) {
    
    echo "You need to order something";
    
}

else {
    
    
    foreach ($gear as $i) {
		$cost += $i;
        
        
    }
    
    If ($currency == "cdn") {
        
        echo "The following odrder details have been calculated in CDN dollars: <br>";
        echo "<ul>
			<li>Total for ordering $items items = $$cost</li>
			<li>Your shipping cost will be $shipping</li>
	</ul>";
        
        
    }
    
    elseif ($currency == "gbp") {
        $cost  = (($cost + $shipping) * $brit);
        $bship = ($shipping * $brit);
        
        echo "The following odrder details have been calculated in British Pounds: <br>";
        echo "<ul>
		<li>Total for ordering $items items = $$cost</li>
		<li>Your shipping cost will be $bship </li>
	</ul>";
    }
    
    
    else {
        
        $cost  = (($cost + $shipping) * $US);
        $uship = ($shipping * $US);
        echo "The following odrder details have been calculated in US Dollars: <br>";
        echo "<ul>
		<li>Total for ordering $items items = $$cost</li>
		<li>Your shipping cost will be $uship </li>
	</ul>";
    }
    
    
}

?>