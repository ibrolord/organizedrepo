        
        <?php
//Check If Empty
if(!isset($_GET["cbox"])){
echo "<marquee direction = 'up' style = 'color: red'; ><h1>At least pick a Paintball Item bruh bruh</h1>
</marquee>
<a href ='ass.html'> Go Back </a> ";}


//If not Empty Run This
    else{
$check = $_GET["cbox"]; //checkbox array
$count = count($check); //count array 
$cost = 0; //set integer for total cost
$ship = $_GET["rad"]; //shipping array
$cost1 = 0; //set integer for shipping cost 


//iterations
foreach($check as $i){
$cost += $i;  
}
        
    foreach($ship as $o){
    $cost1 += $o;
}

$order = 0; //set integer for total calculation
//$conv = $cost;
$drop = $_GET["drop"]; //dropbox
        
if(isset($drop) && $drop == "CDN" ){
    $conv = 1;
    $order = ($cost + $cost1) * $conv;
    $cost1 *= $conv;
echo "<p>The following order details have been calculated in CDN dollars:</p>
<ul><li>Total for ordering $count items = &#36; $order </li>
    <li>Your shipping cost will be: &#36 $cost1 </li>
";
}
        
if(isset($drop) && $drop == "GBP"){
    $conv = 0.61;
    $order = ($cost + $cost1) * $conv;
    $cost1 *= $conv;
echo "<p>The following order details have been calculated in GBP dollars:</p>
<ul><li>Total for ordering $count items = &#36; $order </li>
    <li>Your shipping cost will be: &#36 $cost1 </li>
";  
}
        
if(isset($drop) && $drop == "USD") {
        $conv = 0.74;
     $order = ($cost + $cost1) * $conv;
    $cost1 *= $conv;
echo "<p>The following order details have been calculated in USD dollars:</p>
<ul><li>Total for ordering $count items = &#36; $order </li>
    <li>Your shipping cost will be: &#36 $cost1 </li>
"; 
}
        
    //    echo "<br> $order $cost1   $count  $cost";
    }




?>

