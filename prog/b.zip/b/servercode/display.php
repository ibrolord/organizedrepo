<?php
	//place PHP code here
	/* This is a block comment */
	//echo "This works!!";
	
	//echo $_GET["txtPDexNo"];
	//$pokenum =$pokenum + 1;
	$pokenum = $_GET["txtPDexNo"];
	
	if (($pokenum < 0) || ($pokenum>700))
	{
		echo "Use numbers >0 and <700";
	}
	else
	{
		echo "i've caught $pokenum pokemon";
	}

	echo "<a href='../Pokemon.html'>Go Back</a>";
	
	
?>